package com.example.service

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import java.util.*


class GenerateNumberService: Service(){
    private val binder = LocalBinder()
    private val random = Random()

    override fun onBind(p0: Intent?): IBinder? {
        return binder
    }

    inner class LocalBinder : Binder(){
        fun getService(): GenerateNumberService = this@GenerateNumberService
    }
    fun randomNumber(): Int{
        return random.nextInt(100)
    }
}

