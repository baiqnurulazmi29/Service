package com.example.service

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.media.MediaPlayer
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.IBinder
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var numberService: GenerateNumberService
    private var bound: Boolean=false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        btn_facebook.setOnClickListener({
            val i = Intent(Intent.ACTION_VIEW,
                Uri.parse("http://www.facebook.com/langitinspirasi"))
            startActivity(i)
        })

        btn_instagram.setOnClickListener({
            val i = Intent(Intent.ACTION_VIEW,
                Uri.parse("http://www/instagram.com/langitinspirasi"))
            startActivity(i)
        })

        var MediaPlayer: MediaPlayer? = MediaPlayer.create(this, R.raw.everlong)

        btn_play.setOnClickListener() {

            val intent=Intent(this, MusicService::class.java)
            startService(intent)

        }
        /*
        btn_pause.setOnClickListener{

            val intent=Intent(this, MusicService::class.java)
            startService(intent)

        }*/
        btn_stop.setOnClickListener{

            val intent=Intent(this, MusicService::class.java)
            startService(intent)

        }
        btn_random.setOnClickListener(){

            if (bound){
                val number= numberService.randomNumber()
                txt_number.text = number.toString()
            }
        }

        /*
        btn_play.setOnClickListener{
            MediaPlayer?.start()
        }

        btn_pause.setOnClickListener{
            MediaPlayer?.pause()
        }

        btn_stop.setOnClickListener{
            MediaPlayer?.pause()
            MediaPlayer?.seekTo(0)
        }*/
    }

    override fun onStart() {
        super.onStart()
        Intent(this, GenerateNumberService::class.java).also {
            intent -> bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }
    }

    private val connection : ServiceConnection = object : ServiceConnection{
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as GenerateNumberService.LocalBinder
            numberService = binder.getService()
            bound = true
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            bound = false
        }
    }
}
